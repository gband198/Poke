
package launcher;


public class TileGrass extends Tile {
    
    public TileGrass( int id) {
        super(Assets.grass, id);
    }
    
    
}
