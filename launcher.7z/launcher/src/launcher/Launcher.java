package launcher;

public class Launcher {

    public static void main(String[] args) {
        Juego stegame = new Juego(400,368);
        stegame.start();
    }

}
