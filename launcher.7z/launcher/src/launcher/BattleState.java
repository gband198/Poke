
package launcher;


public class BattleState {
    
}
