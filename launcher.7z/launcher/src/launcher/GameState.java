package launcher;

import java.awt.Graphics;

public class GameState extends State {

    public player PLa;
    public World wor;

    public GameState(Handler handler) {
        super(handler);
          wor = new World(handler,"123.txt");
          handler.setWorld(wor);
        PLa = new player(handler, 40, 40);
      
    }

    @Override
    public void tick() {
        wor.tick();
        PLa.tick();
        
    }

    @Override
    public void render(Graphics g) {
        wor.render(g);
        PLa.render(g);

    }

}
