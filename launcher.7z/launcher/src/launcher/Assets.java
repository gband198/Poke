
package launcher;

import java.awt.image.BufferedImage;


public class Assets {

    
    public static BufferedImage player;
    public static BufferedImage grass;
    public static BufferedImage Rock;
    public static void init(){
    Spritesheet stesheet= new Spritesheet(Imageloader.loadImage("imagenes/trchar167.png"));
    Spritesheet tesheet= new Spritesheet(Imageloader.loadImage("imagenes/WoodsLight.png"));
    Spritesheet esheet= new Spritesheet(Imageloader.loadImage("imagenes/dawn-preview.png"));
    player = stesheet.crop(0, 0, 58, 63);
    grass =tesheet.crop(0,0,30,30);
    Rock=esheet.crop(97,0,47,48);
    
    }
    
    
}
