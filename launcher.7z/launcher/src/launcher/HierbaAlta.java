
package launcher;

import java.awt.Graphics;


public class HierbaAlta extends Tile {
    
    public HierbaAlta( int id) {
        super(Assets.Halta, id);
    }
    
    @Override
    public boolean itssolid(){
    return false;
    }
    public boolean getbattle(){
    return true;
    }
}
    
    

