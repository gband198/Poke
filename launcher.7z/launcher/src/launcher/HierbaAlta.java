
package launcher;

import java.awt.Graphics;


public class HierbaAlta extends StaticEntity {

    public HierbaAlta(Handler handler, float x, float y) {
        super(handler, x, y, Tile.twidght, Tile.theight*2);
    }
    

    @Override
    public void tick() {
        
    }

    @Override
    public void render(Graphics g) {
        
    }
    
  
    
    
}
