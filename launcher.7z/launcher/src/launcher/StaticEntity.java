
package launcher;


public abstract class StaticEntity extends Entity {
    
    public StaticEntity(Handler handler, float x, float y, int widght, int height) {
        super(handler, x, y, widght, height);
    }
    
    public boolean getbattle(){
    return true;
    }
}
