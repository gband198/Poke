
package launcher;

import java.awt.Graphics;


public class player extends creature {
     
    public player(Handler handler,float x, float y) {
        super(handler,x, y, creature.Dwidght, creature.Dheight);
        
    }

    @Override
    public void tick() {  
       getinput();
       moves();
       handler.getGameCamera().centerOentity(this);
    }
    private void getinput(){
    movex=0;
    movey=0;
        if (handler.getkeyBoard().up) {
           movey=-speed; 
        }
        if (handler.getkeyBoard().down) {
           movey=speed; 
        }
        if (handler.getkeyBoard().right) {
           movex=speed; 
        }
        if (handler.getkeyBoard().left) {
           movex=-speed; 
        }
    }

    @Override
    public void render(Graphics g) {
      g.drawImage(Assets.player, (int)(x-handler.getGameCamera().getXoffset()),(int)(y-handler.getGameCamera().getYoffset()),widght,height, null);
    }
    
}
