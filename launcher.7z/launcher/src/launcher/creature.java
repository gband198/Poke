
package launcher;


public abstract class creature extends Entity {
     
     public static final float Defaultspeed= 3.0f;
     public static final int Dwidght=30;
      public static final int Dheight=30; 
    protected float speed; 
    protected float movex,movey; 
    public creature(Handler handler,float x, float y, int widght, int height) {
        super(handler,x, y,widght,height);
        speed= Defaultspeed;
        movex=0;
        movey=0;
    }
    
    
    public void moves(){
    x+=movex;
    y+=movey;
    
    }
    
    
    
    
//||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    public float getMovex() {
        return movex;
    }

    public void setMovex(float movex) {
        this.movex = movex;
    }

    public float getMovey() {
        return movey;
    }

    public void setMovey(float movey) {
        this.movey = movey;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
    
}
