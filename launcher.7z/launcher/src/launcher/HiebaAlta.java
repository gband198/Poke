
package launcher;


public class HiebaAlta extends Tile {
    public HiebaAlta( int id) {
        super(Assets.Halta, id);
    }
    
    public boolean getBattle(){
    return true;
    }
    
    
}
