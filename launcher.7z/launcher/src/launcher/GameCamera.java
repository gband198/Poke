
package launcher;


public class GameCamera {
    private Juego juego;
    private float xoffset,yoffset;

    public GameCamera(Juego juego,float xoffset, float yoffset) {
        this.juego=juego;
        this.xoffset = xoffset;
        this.yoffset = yoffset;
    }
    public void centerOentity(Entity e){
    xoffset=e.getX()-juego.getWidght()/2+ e.widght/2;
    yoffset=e.getY()-juego.getHeight()/2+ e.height/2;
    }
    public void move(float xamt,float yamt){
    xoffset+=xamt;
    yoffset+=yamt;
    }
    
    public float getXoffset() {
        return xoffset;
    }

    public void setXoffset(float xoffset) {
        this.xoffset = xoffset;
    }

    public float getYoffset() {
        return yoffset;
    }

    public void setYoffset(float yoffset) {
        this.yoffset = yoffset;
    }
    
}
