
package launcher;

import java.awt.Graphics;
import java.util.ArrayList;


public class EntityManager {
private Handler handler;
private Juego juego;
private ArrayList<Entity>entitys;

    public EntityManager(Handler handler, Juego juego) {
        this.handler = handler;
        this.juego = juego;
        entitys= new ArrayList<Entity>();
    }

   public void tick(){
       for (int i = 0; i <entitys.size(); i++) {
           Entity e = entitys.get(i);
           e.tick();
       }
  }
    public void render(Graphics g ){
    
  }
    public void addEntity(Entity e){
    entitys.add(e); 
    }
    
/////////////////////////////////////////////////////////////////////////////////
    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public Juego getJuego() {
        return juego;
    }

    public void setJuego(Juego juego) {
        this.juego = juego;
    }

    public ArrayList<Entity> getEntitys() {
        return entitys;
    }

    public void setEntitys(ArrayList<Entity> entitys) {
        this.entitys = entitys;
    }
    
}
