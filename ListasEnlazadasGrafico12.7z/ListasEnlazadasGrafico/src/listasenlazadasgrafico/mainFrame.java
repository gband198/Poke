
package listasenlazadasgrafico;

import javax.swing.DefaultListModel;


public class mainFrame extends javax.swing.JFrame {

    class Nodo{
        int numero;
        Nodo link;
    }
    
    Nodo ptr;
   
    public mainFrame() {
        initComponents();
        DefaultListModel model = new DefaultListModel();
        lista.setModel(model);
        ptr = null;
    }

    void mostrarLista(Nodo ptr){
        DefaultListModel model = (DefaultListModel) lista.getModel();
        model.clear();
        
        Nodo p = ptr;
        while(p != null){
            model.addElement(p.numero);
            p = p.link;
        }
        
    }
    
    Nodo agregarPila(Nodo ptr, int num){
        Nodo p = new Nodo();
        p.numero = num;
        p.link = ptr;
        ptr = p;
        return ptr;
    }
    
    Nodo agregarCola(Nodo ptr, int num){
        Nodo p = new Nodo();
        p.numero = num;
        if(ptr == null){
            ptr = p;
        }else{
            Nodo q = ptr;
            while(q.link != null){
                q = q.link;
            }
            q.link = p;
        }
        return ptr;
    }
    
    Nodo eliminarElem(Nodo ptr, int num){
        Nodo q = ptr;
        Nodo ant = null;
        while(q != null){
            if(q.numero == num){
                if(ant == null){
                    ptr = q.link;
                    q = null;
                }else{
                    ant.link = q.link;
                    q = null;
                }
            }else{
                ant = q;
                q = q.link;
            }
        }
        return ptr;
    }
 
    Nodo invertirlist(Nodo ptr){
        Nodo p= new Nodo();
        Nodo q= new Nodo();
        Nodo r= new Nodo();
       
        if (ptr.link != null) {
            p = ptr;
            q = p.link;
            r = q.link;
            while (r!=null ) {                
                q.link=p;
                p=q;
                r=r.link;
            }
            if (r== null) {
                q.link =p;
                ptr.link=null;
                ptr=q;
            }
        }
    return ptr;
    }
    
    Nodo eliminartod(Nodo ptr, int num) {
        Nodo z = ptr;
        while (z != null) {
          Nodo h=z.link;
          Nodo anth= z;  //ant
            while (h != null) {
                if (z.numero == h.numero) {
                    anth.link = anth.link.link;
                    h = anth.link; 
                } else {
                    anth  = h;
                    h = h.link;
                }
               
            }
            z = z.link;
        }
        return ptr;
    }
   
    Nodo punto6(Nodo ptr){
     Nodo antp = new Nodo();
     Nodo p = new Nodo();
     Nodo q = new Nodo();
      antp.link=ptr;       
        p=ptr.link;
        while (p!= null) {            
            if (p.numero > 0) {
             q.numero= 100;
             antp.link=q;
             q.link=p;
             antp=p;
             p= p.link;
            }else{
                if (p.numero < 0) {
                   
                }
            }   
        }
        
        return ptr;
    } 
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        lista = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        numeroTextField = new javax.swing.JTextField();
        inicioButton = new javax.swing.JButton();
        finButton = new javax.swing.JButton();
        eliminarButton = new javax.swing.JButton();
        elimtod = new javax.swing.JButton();
        invertir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lista.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(lista);

        jLabel1.setText("Número:");

        inicioButton.setText("Inicio");
        inicioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioButtonActionPerformed(evt);
            }
        });

        finButton.setText("Fin");
        finButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finButtonActionPerformed(evt);
            }
        });

        eliminarButton.setText("Eliminar");
        eliminarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarButtonActionPerformed(evt);
            }
        });

        elimtod.setText("eliminar todo");
        elimtod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                elimtodActionPerformed(evt);
            }
        });

        invertir.setText("invertir");
        invertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invertirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(numeroTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inicioButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(finButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eliminarButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(elimtod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(invertir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(numeroTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inicioButton)
                    .addComponent(finButton)
                    .addComponent(eliminarButton)
                    .addComponent(elimtod))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(invertir))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inicioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioButtonActionPerformed
        String numeroString = numeroTextField.getText();
        if(!numeroString.isEmpty()){
            int numero = Integer.parseInt(numeroString);
            ptr = agregarPila(ptr, numero);
            mostrarLista(ptr);
        }
    }//GEN-LAST:event_inicioButtonActionPerformed

    private void finButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finButtonActionPerformed
        String numeroString = numeroTextField.getText();
        if(!numeroString.isEmpty()){
            int numero = Integer.parseInt(numeroString);
            ptr = agregarCola(ptr, numero);
            mostrarLista(ptr);
        }
    }//GEN-LAST:event_finButtonActionPerformed

    private void eliminarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarButtonActionPerformed
        String numeroString = numeroTextField.getText();
        if(!numeroString.isEmpty()){
            int numero = Integer.parseInt(numeroString);
            ptr = eliminarElem(ptr, numero);
            mostrarLista(ptr);
        }
    }//GEN-LAST:event_eliminarButtonActionPerformed

    private void elimtodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_elimtodActionPerformed
     String numeroString = numeroTextField.getText();
        if(!numeroString.isEmpty()){
            int numero = Integer.parseInt(numeroString);
            ptr = eliminartod( ptr, numero);
            mostrarLista(ptr);
        }
    }//GEN-LAST:event_elimtodActionPerformed

    private void invertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invertirActionPerformed

            ptr = invertirlist(ptr);
            mostrarLista(ptr);
         
    }//GEN-LAST:event_invertirActionPerformed
  
     
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton eliminarButton;
    private javax.swing.JButton elimtod;
    private javax.swing.JButton finButton;
    private javax.swing.JButton inicioButton;
    private javax.swing.JButton invertir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> lista;
    private javax.swing.JTextField numeroTextField;
    // End of variables declaration//GEN-END:variables
}
